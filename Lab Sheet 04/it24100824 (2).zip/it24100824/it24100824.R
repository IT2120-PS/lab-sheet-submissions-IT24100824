getwd()
setwd("C:\\Users\\it24100824\\Desktop\\it24100824")

#1
branch_data <- read.table("Exercise.txt",header = TRUE, sep = ",")
fix(branch_data)
str(branch_data)

#3
boxplot(branch_data$sales,
        main="Boxplot of sales",
        ylab="sales amount",
        outline = TRUE,
        horizontal =FALSE)

boxplot(branch_data$Sales_X1,main="Boxplot of Sales",ylab = "Sales")

#4
advertising_summary <- summary(branch_data$Advertising)
print(advertising_summary)
advertising_iqr <- IQR(branch_data$Advertising)
print(paste("IQR for advertising:",advertising_iqr))


#5
find_outliers <- function(x){
  q1 <- quantile(x,0.25)
  q3 <- quantile(x,0.75)
  iqr <- q3 - q1
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 +1.5 * iqr
  
  outliers <- x[x < lower_bound | x > upper_bound]
  
  if(length(outliers) == 0) {
    return ("no outliers detected")
  } else{
    return(sort(outliers))
  } 
 } 
years_outliers <- find_outliers(branch_data$Years)
print(paste("outliers in Years variable:" , paste(years_outliers,collapse = ",")))
  
